Developer: Angelo Ativo
Date: 06-11-2015

Sample usage:

php run.php config.txt verbose;

Replace "config.txt" with target configuration file and "verbose" with desired parameter.


